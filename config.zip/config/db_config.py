db: dict[str,str] = {
    'host':'stocks.cfu1xy0gmqpq.us-east-2.rds.amazonaws.com',
    'user':'ashwanim',
    'password':'axm220114',
    'database':'stocksdb'
}