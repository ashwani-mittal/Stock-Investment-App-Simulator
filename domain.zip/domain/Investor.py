class Investor():
    def __init__(self, id: int ,firstname: str, lastname: str, account_balance: float):
        self.id = id
        self.firstname = firstname
        self.lastname = lastname
        self.account_balance = account_balance

    def __str__(self):
        return f'(ID:{self.id}, First Name: {self.firstname}, Last Name: {self.lastname}, Account Balance: {self.account_balance})'