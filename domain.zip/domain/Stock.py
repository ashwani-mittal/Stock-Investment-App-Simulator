class Stock():
    def __init__(self, stock_ticker,stock_name, stock_price):
        self.stock_ticker = stock_ticker
        self.stock_name = stock_name
        self.stock_price = stock_price
        
    def __str__(self) -> str:
        return f'Ticker: {self.stock_ticker}, Stock Name: {self.stock_name}, Stock Price: {self.stock_price}'