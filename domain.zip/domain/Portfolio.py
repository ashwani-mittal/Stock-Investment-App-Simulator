class Portfolio():
    def __init__(self,investor_id, stock_ticker, quantity):
        self.investor_id = investor_id
        self.stock_ticker = stock_ticker
        self.quantity = quantity

    def __str__(self):
        return f'Investor ID: {self.investor_id}, Stock Ticker: {self.stock_ticker}, Quantity: {self.quantity}'