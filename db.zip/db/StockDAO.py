from mysql.connector import MySQLConnection
from mysql.connector.cursor import MySQLCursor
import db.sql_queries as queries
from domain.Stock import Stock

class StockDAO():
    def __init__(self, connection: MySQLConnection):
        self.connection = connection
    
    def get_all_stocks(self) -> list[Stock]:
        '''
        return all Stocks from the database
        '''
        cursor: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor.execute(queries.get_all_stocks)
        results = cursor.fetchall()
        stocks: list[Stock] = []
        for record in results:
            stocks.append(Stock(
                record['stock_ticker'], 
                record['stock_name'], 
                record['stock_price']
        ))
        return stocks

    def get_stock_by_ticker(self, stock_ticker: str) -> Stock:
        cursor: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor.execute(queries.get_stock_by_ticker, (stock_ticker, ))
        results = cursor.fetchone()
        if results is None:
            return None
        stock: Stock = Stock(results['stock_ticker'] ,results['stock_name'],results['stock_price'])
        return stock
