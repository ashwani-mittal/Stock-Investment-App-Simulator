get_all_investors = 'select * from investors'

delete_investor = 'delete from investors where id = %s'

get_investor_by_id = 'select * from investors where id = %s'

get_portfolio = 'select * from portfolio where investor_id = %s'

check_stock_in_portfolio = 'select * from portfolio where investor_id = %s and stock_ticker = %s'

update_stock_in_portfolio = 'update portfolio set quantity = %s where investor_id = %s and stock_ticker = %s'

add_stock_to_portfolio = 'insert into portfolio (investor_id, stock_ticker, quantity) values (%s, %s, %s)'

# Get stock price
get_stock_price = 'SELECT stock_price FROM stocks WHERE stock_ticker = %s LIMIT 1'

# Get account balance
get_account_balance = 'SELECT account_balance FROM investors WHERE id = %s'

# Update account balance
update_account_balance = 'UPDATE investors SET account_balance =  %s WHERE id = %s'

delete_stock_from_portfolio = 'DELETE FROM portfolio WHERE investor_id = %s AND stock_ticker = %s'

get_all_stocks = 'select * from stocks'

get_stock_by_ticker = 'select * from stocks where stock_ticker = %s'