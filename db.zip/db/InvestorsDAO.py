from mysql.connector import MySQLConnection
from mysql.connector.cursor import MySQLCursor
import db.sql_queries as sql_queries
from domain.Investor import Investor


class InvestorDAO():
    def __init__(self, connection: MySQLConnection):
        self.connection = connection
    
    def get_all(self) -> list[Investor]:
        '''
        return all investors from the database
        '''
        cursor_obj: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor_obj.execute(sql_queries.get_all_investors)
        results = cursor_obj.fetchall()
        investors_list: list[str] = []
        for record in results:
            investors_list.append(Investor(
                record['id'], 
                record['firstname'], 
                record['lastname'],
                record['account_balance']
            ))
        return list(set(investors_list))
    
    def get_investor_by_id(self, investor_id: int) -> Investor:
        cursor_obj: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor_obj.execute(sql_queries.get_investor_by_id, (investor_id, ))
        results = cursor_obj.fetchone()
        if results is None:
            return None
        investor_obj: Investor = Investor(
            results['id'], 
            results['firstname'], 
            results['lastname'], 
            results['account_balance']
        )
        return investor_obj
    
    def deposit(self, investor_id: int, amount: float) -> None:
        try:
            # Check if the investor exists
            investor_obj = self.get_investor_by_id(investor_id)
            if investor_obj is None:
                raise ValueError('Investor does not exist')
            
            # Check if the amount is a number
            if not isinstance(amount, (int, float)):
                raise ValueError('Amount should be a number')
            
            # Update the investor's account balance
            new_balance = float(investor_obj.account_balance) + amount
            cursor_obj: MySQLCursor = self.connection.cursor(dictionary=True)
            cursor_obj.execute(sql_queries.update_account_balance, (new_balance, investor_id))
            self.connection.commit()
            investor_obj.account_balance = new_balance
            print(f'Deposit successful. New balance: {investor_obj.account_balance}')
            
        except ValueError as error_message:
            print(str(error_message))
    
    def withdrawal(self, investor_id: int, amount: float) -> None:
        try:
            amount = float(amount)
        except ValueError:
            print('Amount should be a number')
            return
            
        investor_obj = self.get_investor_by_id(investor_id)
        if not investor_obj:
            print('Investor does not exist')
            return
        
        if amount > investor_obj.account_balance:
            print('Insufficient funds for withdrawal.')
            return
        
        new_balance = float(investor_obj.account_balance) - amount
        cursor_obj: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor_obj.execute(sql_queries.update_account_balance, (new_balance, investor_id))
        self.connection.commit()
        investor_obj.account_balance = new_balance
        print(f'Withdrawal successful. New balance: {new_balance}')
    
    def delete(self, investor_id: int) -> None:
        cursor_obj: MySQLCursor = self.connection.cursor(dictionary=True)
        cursor_obj.execute(sql_queries.delete_investor, (investor_id, ))
        self.connection.commit()
