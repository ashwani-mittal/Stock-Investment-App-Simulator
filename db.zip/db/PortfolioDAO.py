from mysql.connector import MySQLConnection
from mysql.connector.cursor import MySQLCursor
import db.sql_queries as queries
from domain.Portfolio import Portfolio
from domain.exceptions.AddStockFailure import AddStockFailure

class PortfolioDAO():
    def __init__(self, connection: MySQLConnection):
        self.connection = connection
    
    def get_portfolio(self, investor_id: int) -> list[Portfolio]:
        try:
            cursor: MySQLCursor = self.connection.cursor(dictionary=True)
            portfolios: list[Portfolio] = []
            cursor.execute(queries.get_portfolio, (investor_id, ))
            results = cursor.fetchall()
            if not results:
                raise ValueError('Invalid Investor ID')
            for record in results:
                portfolios.append(Portfolio(record['investor_id'], 
                                            record['stock_ticker'], 
                                            record['quantity']))
            return portfolios
        except ValueError as e:
            raise

    def add_stock(self, investor_id: int, stock_ticker: str, quantity: int):
        try:
            cursor: MySQLCursor = self.connection.cursor(dictionary=True)
            
            # Get the stock price from the stocks table
            cursor.execute(queries.get_stock_price, (stock_ticker,))
            stock_price = cursor.fetchone()['stock_price']
            
            # Calculate the total purchase price
            purchase_price = quantity * stock_price
            
            # Check if the investor has enough account balance
            cursor.execute(queries.get_account_balance, (investor_id,))
            account_balance = cursor.fetchone()['account_balance']
            if account_balance < purchase_price:
                raise ValueError('Insufficient account balance')
            
            # Check if the stock is already in the portfolio
            cursor.execute(queries.check_stock_in_portfolio, (investor_id, stock_ticker))
            result = cursor.fetchone()
            if result:
                # If combination exists, update quantity
                new_quantity = result['quantity'] + quantity
                cursor.execute(queries.update_stock_in_portfolio, (new_quantity, investor_id, stock_ticker))
            else:
                # If combination does not exist, insert new row
                cursor.execute(queries.add_stock_to_portfolio, (investor_id, stock_ticker, quantity))
            
            # Deduct the purchase price from the investor's account balance
            new_balance = account_balance - purchase_price
            cursor.execute(queries.update_account_balance, (new_balance, investor_id))
        except AddStockFailure as e:
            print(f'Failed to add stock: {stock_ticker} to portfolio of investor: {investor_id}')
        except ValueError as e:
            print("Insufficient funds")
        self.connection.commit()

    def sell_stock(self, investor_id: int, stock_ticker: str, sell_quantity: int, sell_price: float):
        try:
            cursor: MySQLCursor = self.connection.cursor(dictionary=True)
            
            # Check if the stock is in the portfolio
            cursor.execute(queries.check_stock_in_portfolio, (investor_id, stock_ticker))
            result = cursor.fetchone()
            if not result:
                raise ValueError('Stock not found in portfolio')

            # Check if there is enough quantity to sell
            quantity = result['quantity']
            if sell_quantity > quantity:
                raise ValueError('Insufficient stock holdings')

            # Get the stock price from the stocks table
            cursor.execute(queries.get_stock_price, (stock_ticker,))
            stock_price = cursor.fetchone()['stock_price']

            # Calculate the total sale price
            sale_price = sell_quantity * sell_price

            # Update the portfolio table
            new_quantity = quantity - sell_quantity
            if new_quantity > 0:
                cursor.execute(queries.update_stock_in_portfolio, (new_quantity, investor_id, stock_ticker))
            else:
                cursor.execute
        except ValueError as e:
            print(str(e))
            return
        self.connection.commit()
    
