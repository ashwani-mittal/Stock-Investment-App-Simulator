from mysql.connector import MySQLConnection, connect
from config.db_config import db

def get_connection() -> MySQLConnection:
    return connect(**db)


